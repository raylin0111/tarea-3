<?php
include("conexion.php");
$con=conectar();

$sql="SELECT * FROM conctato";
$query=mysqli_query($con,$sql);

$row=mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <title>Usuarios</title>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            
            <div class="col-md-3">
                <h1>Nuevo conctato</h1>
                <form action="insertar.php" method="POST">
                    <input type="number" class="form-control mb-3" name="codigo" placeholder="codigo">
                    <input type="text" class="form-control mb-3" name="Nombre" placeholder="Nombre">
                    <input type="text" class="form-control mb-3" name="Apellido" placeholder="Apellido">
                    <input type="text" class="form-control mb-3" name="email" placeholder="email">

                    <input type="submit" class="btn btn-primary">
                </form>
            </div>

            <div class="col-md-8">
                <table class="table">
                    <thead class="table-success table-striped">
                        <tr>
                            <th>codigo</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>email</th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                            while($row=mysqli_fetch_array($query)){ 
                        ?>                    

                        <tr>
                            <th><?php echo $row['codigo']?></th>
                            <th><?php echo $row['Nombre']?></th>
                            <th><?php echo $row['Apellido']?></th>
                            <th><?php echo $row['email']?></th>

                            <th><a href="actualizar.php?id=<?php echo $row['codigo']?>" class="btn btn-info">Editar</a></th>
                            <th><a href="delete.php?id=<?php echo $row['codigo']?>" class="btn btn-danger">Eliminar</a></th>
                        </tr>

                        <?php
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>