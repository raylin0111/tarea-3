<?php

include("conexion.php");
$con=conectar();

$codigo=$_POST['codigo'];
$nombre=$_POST['Nombre'];
$apellido=$_POST['Apellido'];
$email=$_POST['email'];

$sql="UPDATE conctato SET nombre='$nombre',apellido='$apellido',email='$email' WHERE codigo='$codigo'";
$query= mysqli_query($con,$sql);

if($query){
   header("location: usuariosd.php");

}