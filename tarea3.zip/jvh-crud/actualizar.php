<?php

include("conexion.php");
$con=conectar();

$id=$_GET['id'];

$sql="SELECT * FROM conctato WHERE codigo='$id'";
$query= mysqli_query($con,$sql);

$row=mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>actualizar</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">

</head>
<body>
<div class="container mt-5">
                <form action="update.php" method="POST">

                <input type="hidden" name="codigo" value="<?php echo $row['codigo']   ?>">

                    <input type="text" class="form-control mb-3" name="Nombre" placeholder="Nombre" value="<?php echo $row['Nombre']  ?>">
                    <input type="text" class="form-control mb-3" name="Apellido" placeholder="Apellido" value="<?php echo $row['Apellido']  ?>">
                    <input type="text" class="form-control mb-3" name="email" placeholder="email" value="<?php echo $row['email']  ?>">

                    <input type="submit" class="btn btn-primary btn-block" value="actualizar">
                </form>
            </div>
</body>
</html>